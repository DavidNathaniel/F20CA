class DialogueManager():
    def __init__(self):
        pass

    def sendSlotPrompt():
        pass

    def sendClarification():
        pass

    def askForSlot():
        pass

    def convert_stringtodict():
        pass

    def updateSlots():
        pass
    
    def check_empty_slots():
        pass
    