# To my team members:

##### step1:

Before using, run the following command:

```python
$ python setup.py install
```

##### step2:

Microsoft Visual C++ 14.0 or greater is required.

Get it with "Microsoft C++ Build Tools": https://visualstudio.microsoft.com/visual-cpp-build-tools/

##### step3:

At the same time, you need to have the following libraries:

```
prophet
Retico
retico-core
pyaudio
flexx
google-cloud-speech~=2.15
rasa-nlu
torch==1.13.1
transformers
webrtcvad
speechbrain
pydantic
httpx
distro
```



# Start

run app.py

Adding - Gregor